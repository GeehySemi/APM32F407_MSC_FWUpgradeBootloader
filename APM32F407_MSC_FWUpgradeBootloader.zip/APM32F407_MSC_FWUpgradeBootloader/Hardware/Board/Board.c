/*!
 * @file       Board.c
 *
 * @brief      This file provides firmware functions to manage Leds and push-buttons
 *
 * @version    V1.0.0
 *
 * @date       2021-09-18
 *
 */

#include "Board.h"

#if defined (APM32F407_MINI)
#include "Board_APM32F407_MINI.c"

#elif defined (APM32F407_ELE_HUETB)
#include "Board_APM32F407_ELE_HUETB.c"

#else
#error "Please select first the APM32 board to be used (in board.c)"
#endif
