/*!
 * @file       Board.h
 *
 * @brief      Header file for Board
 *
 * @version    V1.0.0
 *
 * @date       2021-09-18
 *
 */
#ifndef BOARD_H
#define BOARD_H

#if defined (APM32F407_MINI)
#include "Board_APM32F407_MINI.h"

#elif defined (APM32F407_ELE_HUETB)
#include "Board_APM32F407_ELE_HUETB.h"

#else
#error "Please select first the APM32  board to be used (in board.h)"
#endif

#endif
