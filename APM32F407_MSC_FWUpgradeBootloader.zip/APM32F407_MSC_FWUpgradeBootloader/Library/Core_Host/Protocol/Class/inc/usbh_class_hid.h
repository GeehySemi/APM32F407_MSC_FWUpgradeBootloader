/*!
 * @file        usbh_class_hid.h
 *
 * @brief       id class handler header file
 *
 * @version     V1.0.0
 *
 * @date        2021-10-11
 *
 */

#ifndef __USBH_CLASS_HID
#define __USBH_CLASS_HID

#include "usbh_core.h"

#define HID_POLL_TIME          10


typedef struct
{
  uint8_t              x;
  uint8_t              y;
  uint8_t              button;
}HID_MOUSE_Data_T;


typedef enum
{
    HID_REQ_IDLE,
    HID_REQ_GET_DEV_DESC,
    HID_REQ_GET_REQ_DEV_DESC,
    HID_REQ_SET_IDLE,
    HID_REQ_SET_PROTOCOL,
    HID_REQ_CONFIGURED_OK,
} USBH_HID_REQ_STATE_T;

typedef enum
{
    HID_IDLE,
    HID_SYNC,
    HID_GET_DATA,
    HID_POLL,
} USBH_HID_STATE_T;


typedef void (*HID_REQ_Handler_T)(void);
typedef void (*HID_Handler_T)(void);


void USBH_HID_InitHandler(void);
void USBH_HID_DeInitHandler(void);
void USBH_HID_ReqHandler(void);
void USBH_HID_CoreHandler(void);

#endif
