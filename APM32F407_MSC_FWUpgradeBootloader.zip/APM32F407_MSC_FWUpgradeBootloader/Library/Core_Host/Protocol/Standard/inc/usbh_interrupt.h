/*!
 * @file        usbd_interrupt.h
 *
 * @brief       USB interrupt handle
 *
 * @version     V1.0.0
 *
 * @date        2021-10-09
 *
 */
#ifndef __USBH_INTERRUPT_H_
#define __USBH_INTERRUPT_H_


typedef enum
{
    PKTSTS_IN                = 2,  //!< recevied IN packet
    PKTSTS_IN_XFER_COMPLETE  = 3,  //!< Transfer IN packet Complete
    PKTSTS_DATA_ISO_ERR      = 5,  //!< Packer data Isochronous Error
    PKTSTS_CHANNEL_HALT      = 7,  //!< channel halt
} GRXSTS_PKTSTS_T;

void USBH_OTG_IsrHandler(void);

#endif
