/*!
 * @file        usbh_channel.h
 *
 * @brief       USB host channel handler function head file
 *
 * @version     V1.0.0
 *
 * @date        2021-10-09
 *
 */

#ifndef __USBH_CHANNEL_H
#define __USBH_CHANNEL_H

#include "drv_usb.h"


#define USBH_CHANNEL_MAX_NUM    8

typedef enum
{
    USBH_CH_FAIL,
    USBH_CH_OK
} USBH_CH_STATUS_T;


int8_t USBH_CH_AllocChannel(uint8_t epAddr);

void USBH_CH_FreeChannel(uint8_t channelNum);
void USBH_CH_FreeAllChannel(void);

USBH_CH_STATUS_T USBH_CH_OpenChannel(uint8_t  channelNum,
                                     uint8_t  devAddr,
                                     uint8_t  epType,
                                     uint16_t maxPackSize);

uint8_t USBH_ReadEpAddrChannel(uint8_t epAddr);

#endif
