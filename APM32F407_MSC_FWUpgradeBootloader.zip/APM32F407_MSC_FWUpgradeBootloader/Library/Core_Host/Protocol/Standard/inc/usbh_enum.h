/*!
 * @file        usbh_enum.h
 *
 * @brief       USB host enum hander function head file
 *
 * @version     V1.0.0
 *
 * @date        2021-10-12
 *
 */


#ifndef USBH_ENUM_H
#define USBH_ENUM_H

#include "drv_usb.h"
#include "usbh_stdReq.h"
#include "usbh_core.h"


/** Enum handler */
typedef void (*ENUM_CoreHandler_T)(void);

extern ENUM_CoreHandler_T ENUM_CoreHandler[];

#endif

