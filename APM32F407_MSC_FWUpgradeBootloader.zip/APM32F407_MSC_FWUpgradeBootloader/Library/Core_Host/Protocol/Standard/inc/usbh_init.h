/*!
 * @file        usbd_init.h
 *
 * @brief       USB device initialization
 *
 * @version     V1.0.0
 *
 * @date        2021-10-09
 *
 */
#ifndef __USBH_INIT_H_
#define __USBH_INIT_H_

#include "usbh_core.h"

void USBH_Init(USBH_InitParam_T *param);
void USBH_DeInit(void);
void USB_HostInit(void);
void USB_GlobalInit(void);
#endif
