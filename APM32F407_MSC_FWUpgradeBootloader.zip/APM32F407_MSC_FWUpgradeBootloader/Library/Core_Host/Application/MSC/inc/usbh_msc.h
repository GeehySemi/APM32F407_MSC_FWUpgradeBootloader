/*!
 * @file        usbh_msc.h
 *
 * @brief       USB MSC core function head file
 *
 * @version     V1.0.0
 *
 * @date        2021-10-26
 *
 */
#ifndef __USBH_MSC_H_
#define __USBH_MSC_H_

#include "usbh_core.h"
#include "ff.h"
#include "diskio.h"

extern FATFS *fs[FF_VOLUMES];
extern char fileScanPath[255];

/** function declaration*/
void USBH_MSC_Init(void);
uint8_t USBH_DeviceStatus(void);
uint8_t USB_DiskRead(uint8_t* buffer, uint32_t sector, uint32_t cnt);
uint8_t USB_DiskWrite(uint8_t* buffer, uint32_t sector, uint32_t cnt);

/** function declaration*/
FRESULT FATFS_ScanFiles(char* path);
void FATFS_WriteReadFile(FIL *file);

#endif
