/*!
 * @file        usbh_cdc.h
 *
 * @brief       USB CDC core function
 *
 * @version     V1.0.0
 *
 * @date        2021-10-09
 *
 */
#include "usbh_cdc.h"
#include "usbh_init.h"
#include "usbh_class_cdc.h"
#include "Board.h"

/*!
 * @brief       Init USB host CDC
 *
 * @param       None
 *
 * @retval      None
 */
void USBH_CDC_Init(void)
{
    USBH_InitParam_T param;

    param.classInitHandler = USBH_CDC_ClassInitHandler;
    param.classDeInitHandler = USBH_CDC_ClassDeInitHandler;
    param.classReqHandler = USBH_CDC_ClassReqHandler;
    param.classCoreHandler = USBH_CDC_CoreHandler;
    param.suspendHandler = NULL;
    param.wakeUpHandler = NULL;
    param.intHandler = NULL;

    USBH_Init(&param);
}

