/*!
 * @file        usbh_hid.h
 *
 * @brief       USB HID core function head file
 *
 * @version     V1.0.0
 *
 * @date        2021-10-09
 *
 */
#ifndef __USBH_HID_H_
#define __USBH_HID_H_

#include "usbh_core.h"

void USBH_CDC_Init(void);

#endif
