/*!
 * @file        usb_config.h
 *
 * @brief       USB configuration file
 *
 * @version     V1.0.0
 *
 * @date        2021-12-03
 *
 */

#ifndef __USB_CONFIG_H
#define __USB_CONFIG_H

#define USBH_DEVICE_DEFAULT_ADDRESS           0
#define USBH_DEVICE_CONFIGURED_ADDRESS        1

#define CFG_DESC_MAX_LEN                      256
#define STRING_DESC_MAX_LEN                   256

#define INTERFACE_DESC_MAX_NUM                3
#define ENDPOINT_DESC_MAX_NUM                 3

/** define 0 to disable, 1 to enable */
#define USB_VBUS_SWITCH                       0
/** define 0 to disable, 1 to enable */
#define USB_SOF_OUTPUT_SWITCH                 0

#define USB_EP0_PACKET_SIZE                   64

#ifdef USB_OTG_FS
#define USB_FS_RX_FIFO_SIZE                   128
#define USB_FS_NP_TXH_FIFO_SIZE               128
#define USB_FS_P_TXH_FIFO_SIZE                0

#else //!< USB_OTG_HS_CORE
#define USB_HS_RX_FIFO_SIZE                   512
#define USB_HS_NP_TXH_FIFO_SIZE               256
#define USB_HS_P_TXH_FIFO_SIZE                256
#endif

#define USE_DEFAULT                           0
#define USE_TIMER                             1
#define USE_USER                              2

/** Change the delay function source */
#define DELAY_SOURCE                          USE_TIMER

#endif
