/*!
 * @file        usbh_hid.h
 *
 * @brief       USB HID core function
 *
 * @version     V1.0.0
 *
 * @date        2021-10-09
 *
 */
#include "usbh_hid.h"
#include "usbh_init.h"
#include "usbh_class_hid.h"

/*!
 * @brief       Init USB host HID
 *
 * @param       None
 *
 * @retval      None
 */
void USBH_HID_Init(void)
{
    USBH_InitParam_T param;

    param.classInitHandler = USBH_HID_InitHandler;
    param.classDeInitHandler = USBH_HID_DeInitHandler;
    param.classReqHandler  = USBH_HID_ReqHandler;
    param.classCoreHandler = USBH_HID_CoreHandler;
    param.suspendHandler = NULL;
    param.wakeUpHandler = NULL;
    param.intHandler = NULL;

    USBH_Init(&param);
}

