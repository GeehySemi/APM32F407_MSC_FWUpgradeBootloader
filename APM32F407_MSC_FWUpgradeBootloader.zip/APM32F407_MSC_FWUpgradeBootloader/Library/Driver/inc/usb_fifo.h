/*!
 * @file        usb_fifo.h
 *
 * @brief       USB fifo header file
 *
 * @version     V1.0.0
 *
 * @date        2021-10-25
 *
 */
#ifndef __USB_FIFO_H_
#define __USB_FIFO_H_

#include "drv_usb.h"

/*!
 * @brief       Write the data to TxFIFO.
 *
 * @param       fifoNum: TxFIFO number
 *
 * @param       data: data to be writed in TxFIFO.
 *
 * @retval      None
 */
#define USB_OTG_WriteTxFifoData(fifoNum, data)   (USB_OTG_FIFO->FIFO[fifoNum].DATA = data)

/*!
 * @brief     Read the RxFIFO data
 *
 * @param     None
 *
 * @retval    Return RxFIFO data
 */
#define USB_OTG_ReadRxFifoData()                 (USB_OTG_FIFO->FIFO[0].DATA)


void USB_FIFO_ReadRxFifoPacket(uint8_t *buf, uint32_t len);
void USB_FIFO_WriteFifoPacket(uint8_t fifoNum, uint8_t *buf, uint32_t len);

#endif
