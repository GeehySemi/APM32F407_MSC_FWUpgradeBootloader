/*!
 * @file        usb_fifo.c
 *
 * @brief       USB fifo handler
 *
 * @version     V1.0.0
 *
 * @date        2021-10-25
 *
 */

#include "usb_fifo.h"

/*!
 * @brief       Read the RxFIFO packet to buffer
 *
 * @param       rBuf:    Buffer pointer
 *
 * @param       rLen:    Buffer length
 *
 * @retval      None
 */
void USB_FIFO_ReadRxFifoPacket(uint8_t *rBuf, uint32_t rLen)
{
    __IO uint32_t i = 0;
    __IO uint32_t temp = 0;

    for( i = 0; i < rLen / 4; i++)
    {
        *(__packed uint32_t *)rBuf = USB_OTG_ReadRxFifoData();
        rBuf += 4 ;
    }

    if (rLen & 0x3)
    {
        temp = USB_OTG_ReadRxFifoData();
        for (i = 0; i < (rLen & 0x3); i++)
        {
            rBuf[i] = temp >> (i << 3);
        }
    }
}

/*!
 * @brief       Write a buffer of data to a selected endpoint
 *
 * @param       ep:     Endpoint number
 *
 * @param       wBuf:   The pointer to the buffer of data to be written to the endpoint
 *
 * @param       wLen:   Number of data to be written (in bytes)
 *
 * @retval      None
 */
void USB_FIFO_WriteFifoPacket(uint8_t ep, uint8_t *wBuf, uint32_t wlen)
{
    uint32_t wordCnt = 0 , i = 0;

    wordCnt =  (wlen + 3) / 4;

    for (i = 0; i < wordCnt; i++)
    {
        USB_OTG_WriteTxFifoData(ep, *((__packed uint32_t *)wBuf) );
        wBuf+=4;
    }

}
