/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2022-10-18
 *
 */
#include "Board.h"
#include "apm32f4xx_misc.h"
#include "usbh_msc.h"
#include "usbh_channel.h"
#include <stdio.h>

/*!
 * @brief       Main program
 *
 * @param       None
 *
 * @retval      int
 */
int main(void)
{
    /* Set the Vector Table base address at 0x0800C000 */
    NVIC_ConfigVectorTable(NVIC_VECT_TAB_FLASH, 0xC000);
    
    /* Init USB host MSC */
    USBH_MSC_Init();
    
    printf(">> USB FW Upgrade Application\r\n");
    printf(">> Please insert the U disk for read file\r\n");
    
    while(1)
    {
        USBH_PollingProcess();
    }
}


