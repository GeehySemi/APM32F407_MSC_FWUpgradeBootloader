/*!
 * @file        main.h
 *
 * @brief       Header for main.c module
 *
 * @version     V1.0.0
 *
 * @date        2022-10-18
 *
 */
#ifndef MAIN_H
#define MAIN_H

#include "Board.h"
#include "stdio.h"

#include "apm32f4xx.h"
#include "apm32f4xx_can.h"
#include "apm32f4xx_misc.h"
#include "apm32f4xx_gpio.h"
#include "apm32f4xx_usart.h"
#include "apm32f4xx_misc.h"

/** extern variables*/


#ifdef __cplusplus
  extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
