/*!
 * @file        main.c
 *
 * @brief       Main program body
 *
 * @version     V1.0.0
 *
 * @date        2022-10-18
 *
 */
#include "Board.h"
#include "apm32f4xx_misc.h"
#include "usbh_msc.h"
#include "usb_user.h"
#include "usb_iap.h"
#include "usbh_channel.h"
#include "bsp_flash.h"
#include <stdio.h>

/*!
 * @brief       Main program
 *
 * @param       None
 *
 * @retval      int
 */
int main(void)
{
    /* Set the Vector Table base address at 0x08000000 */
    NVIC_ConfigVectorTable(NVIC_VECT_TAB_FLASH, 0x00);
    
    /* Init USB host MSC */
    USBH_MSC_Init();

    /* Flash unlock */
    FLASH_FlashInit();
    
    printf(">> USB FW Upgrade Bootloader\r\n");
    printf(">> Please insert the U disk for firmware upgrade\r\n");
    
    userApplicationState = USER_APP_FS_INIT;
    
    if(!APM_MINI_PBGetState(BUTTON_KEY1))
    {
        userApplicationState = USER_APP_FS_INIT;
        
        printf(">> Please release KEY1 and system will enter firmware upgrade mode\r\n");
        while(!APM_MINI_PBGetState(BUTTON_KEY1));
    }
    else
    {
        USB_IAP_Jump2App();
    }
    
    while(1)
    {
        USBH_PollingProcess();
    }
}


