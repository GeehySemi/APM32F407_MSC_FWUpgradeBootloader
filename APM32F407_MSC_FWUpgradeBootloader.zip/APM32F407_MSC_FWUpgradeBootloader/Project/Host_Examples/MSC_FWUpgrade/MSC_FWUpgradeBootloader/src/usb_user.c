/*!
 * @file        usb_user.c
 *
 * @brief       usb user configuration
 *
 * @version     V1.0.0
 *
 * @date        2022-10-18
 *
 */
#include "usb_user.h"
#include "usbh_core.h"
#include "usb_board.h"
#include "usbh_msc.h"
#include "usbh_class_msc.h"
#include "usb_iap.h"

FATFS fatfs;
FIL file;
FIL fileR;
DIR dir;
FILINFO fno;

USER_APP_STATE_T userApplicationState = USER_APP_JUMP;
/* user application error table */
const char *userAppErrorTable[] = {
    "USER_APP_OK",
    "USER_APP_ERR_FATFS",
    "USER_APP_ERR_DISK_WP",
    "USER_APP_ERR_FSIZE_OVER",
    "USER_APP_ERR_FMC_ERASE",
    "USER_APP_ERR_FMC_PG",
    "USER_APP_ERR_FMC_WP",
};

static void USER_InitHandler(void);
static void USER_DeInitHandler(void);
static void USER_ResetDevHandler(void);
static void USER_DevAttachedHandler(void);
static void USER_DevDetachedHandler(void);
static void USER_DevSpeedDetectedHandler(uint8_t speed);
static void USER_DevDescHandler(void *devDesc);
static void USER_CfgDescHandler(void *cfgDesc, void *interface);
static void USER_ManufacturerStringHandler(void *mfcDesc);
static void USER_ProductStringHandler(void *productDesc);
static void USER_SerialNumStringHandler(void *serialDesc);
static void USER_EnumDoneHandler(void);
static USER_STATE_T USER_UserInputHandler(void);
static USER_STATE_T USER_ApplicationHandler(void);
static void USER_DeviceNotSupportedHandler(void);
static void USER_UnrecoveredErrHandler(void);

#if (DELAY_SOURCE != USE_DEFAULT)
static void USB_USER_Delay(uint32_t cnt);
#endif

USB_UserCallBack_T g_userCallback =
{
    USER_InitHandler,
    USER_DeInitHandler,
    USER_ResetDevHandler,
    USER_DevAttachedHandler,
    USER_DevDetachedHandler,
    USER_DevSpeedDetectedHandler,
    USER_DevDescHandler,
    USER_CfgDescHandler,
    USER_ManufacturerStringHandler,
    USER_ProductStringHandler,
    USER_SerialNumStringHandler,
    USER_EnumDoneHandler,
    USER_UserInputHandler,
    USER_ApplicationHandler,
    USER_DeviceNotSupportedHandler,
    USER_UnrecoveredErrHandler,

#if (DELAY_SOURCE == USE_DEFAULT)
    NULL
#else
    USB_USER_Delay
#endif
};

/*!
 * @brief       USB init
 *
 * @param       None
 *
 * @retval      None
 */
static void USER_InitHandler(void)
{
    USART_Config_T usartConfig;

    /* Configure USART */
    usartConfig.baudRate = 115200;
    usartConfig.wordLength = USART_WORD_LEN_8B;
    usartConfig.stopBits = USART_STOP_BIT_1;
    usartConfig.parity = USART_PARITY_NONE ;
    usartConfig.mode = USART_MODE_TX_RX;
    usartConfig.hardwareFlow = USART_HARDWARE_FLOW_NONE;

    APM_BOARD_COMInit(COM1,&usartConfig);

    APM_MINI_LEDInit(LED2);
    APM_MINI_LEDInit(LED3);
    APM_MINI_PBInit(BUTTON_KEY1, BUTTON_MODE_GPIO);
    APM_MINI_PBInit(BUTTON_KEY2, BUTTON_MODE_GPIO);
}

/*!
 * @brief       USB error handler
 *
 * @param       None
 *
 * @retval      None
 */
void USER_ErrorHandler(uint8_t errCode)
{
    while(1)
    {
//        printf("%s\r\n",userAppErrorTable[errCode]);
        APM_MINI_LEDToggle(LED2);
    }
}

/*!
 * @brief       USB de-init handler
 *
 * @param       None
 *
 * @retval      None
 */
static void USER_DeInitHandler(void)
{
    userApplicationState = USER_APP_FS_INIT;
    printf(">> Host Re-Initialize.\r\n");
}

/*!
 * @brief       USB reset device hanlder
 *
 * @param       None
 *
 * @retval      None
 */
static void USER_ResetDevHandler(void)
{
    printf(">> Reset USB Device.\r\n");
}

/*!
 * @brief       USB device attached handler
 *
 * @param       None
 *
 * @retval      None
 */
static void USER_DevAttachedHandler(void)
{
    printf(">> Device Attached.\r\n");
}

/*!
 * @brief       USB device detached handler
 *
 * @param       None
 *
 * @retval      None
 */
static void USER_DevDetachedHandler(void)
{
    printf(">> Device Disconnected.\r\n");
}

/*!
 * @brief       USB device speed detected handler
 *
 * @param       None
 *
 * @retval      None
 */
static void USER_DevSpeedDetectedHandler(uint8_t speed)
{
    switch (speed)
    {
        case USBH_DEVICE_SPEED_HS:
            printf(">> Device Speed : High Speed.\r\n");
            break;
        case USBH_DEVICE_SPEED_FS:
            printf(">> Device Speed : Full Speed.\r\n");
            break;
        case USBH_DEVICE_SPEED_LS:
            printf(">> Device Speed : Low Speed.\r\n");
            break;
        default :
            printf(">> Unknown Speed.\r\n");
            break;
    }
}

/*!
 * @brief       USB get device description handler
 *
 * @param       None
 *
 * @retval      None
 */
static void USER_DevDescHandler(void *devDesc)
{
    USBH_DeviceDesc_T *desc = devDesc;

    printf(">> VID : 0x%04X\r\n", desc->idVendor[0] | desc->idVendor[1] << 8);
    printf(">> PID : 0x%04X\r\n", desc->idProduct[0] | desc->idProduct[1] << 8);
    printf(">> Endpoint 0 max pack size is %d\r\n", desc->bMaxPacketSize);
}

/*!
 * @brief       USB get configure description handler
 *
 * @param       None
 *
 * @retval      None
 */
static void USER_CfgDescHandler(void *cfgDesc, void *interface)
{
    USBH_Interface_T *itf = interface;
    uint8_t i;

    switch (itf->itfDesc.bInterfaceClass)
    {
        case 0x08:
            printf(">> This is a Mass Storage Class Device.\r\n");
            break;
        case 0x03:
            printf(">> This is a HID Class Device.\r\n");
            break;
        case 0x0A:
            printf(">> This is a Communications Class Device.\r\n");
            break;
        default :
            printf(">> Class Code is : 0x%02X\r\n", itf->itfDesc.bInterfaceClass);
            break;
    }
    
    printf(">> Use %d endpoint:\r\n", itf->itfDesc.bNumEndpoints);
    
    for (i = 0; i < itf->itfDesc.bNumEndpoints; i++)
    {
        printf("    Endpoint 0x%02X: max pack size is %d bytes\r\n", \
        itf->epDesc[i].bEndpointAddress,
        itf->epDesc[i].wMaxPacketSize[0] | itf->epDesc[i].wMaxPacketSize[1] << 8);
    }
}

/*!
 * @brief       USB get manufacture string handler
 *
 * @param       None
 *
 * @retval      None
 */
static void USER_ManufacturerStringHandler(void *mfcDesc)
{
    printf(">> Manufacturer : %s\r\n", (uint8_t*)mfcDesc);
}

/*!
 * @brief       USB get product string handler
 *
 * @param       None
 *
 * @retval      None
 */
static void USER_ProductStringHandler(void *productDesc)
{
    printf(">> Product : %s\r\n", (uint8_t*)productDesc);
}

/*!
 * @brief       USB get serial number string handler
 *
 * @param       None
 *
 * @retval      None
 */
static void USER_SerialNumStringHandler(void *serialDesc)
{
    printf(">> SerialNumber : %s\r\n", (uint8_t*)serialDesc);
}

/*!
 * @brief       USB enum done handler
 *
 * @param       None
 *
 * @retval      None
 */
static void USER_EnumDoneHandler(void)
{
    printf(">> USB Enum Done.\r\n");
}

/*!
 * @brief       USB user input handler
 *
 * @param       None
 *
 * @retval      None
 */
static USER_STATE_T USER_UserInputHandler(void)
{
    return USER_OK;
}

/*!
 * @brief       USB user application handler
 *
 * @param       None
 *
 * @retval      None
 */
static USER_STATE_T USER_ApplicationHandler(void)
{
    switch(userApplicationState)
    {
        case USER_APP_FS_INIT:
            printf(">> USER_APP_FS_INIT\r\n");
            
            /* Initialises the File System*/
            if (f_mount(&fatfs, IAP_DISK_PATH, 0) != FR_OK)
            {
                USER_ErrorHandler(USER_APP_ERR_FATFS);
            }
            
            /* Flash Disk is write protected */
            if(g_MSCInfo.storageInfo.writeProtect == DISK_WRITE_PROTECTED)
            {
                USER_ErrorHandler(USER_APP_ERR_DISK_WP);
            }
            
            /* Go to IAP menu */
            userApplicationState = USER_APP_IAP;
            break;
        
        case USER_APP_IAP:
            printf(">> USER_APP_IAP\r\n");
        
            /* Writes Flash memory */
            USB_IAP_Download();
        
            /* Reads all flash memory */
            USB_IAP_Upload();
        
            /* Go to JUMP menu */
            userApplicationState = USER_APP_JUMP;
            break;
        
        case USER_APP_JUMP:
            printf(">> USER_APP_JUMP\r\n");
            /* Jumps to user application code located in the internal Flash memory */
            USB_IAP_Jump2App();
            break;
        
        default:
            break;
    }

    return USER_OK;
}

/*!
 * @brief       USB device not support handler
 *
 * @param       None
 *
 * @retval      None
 */
static void USER_DeviceNotSupportedHandler(void)
{
    printf(">> Device is not Supported!\r\n");
}

/*!
 * @brief       USB unrecovered error handler
 *
 * @param       None
 *
 * @retval      None
 */
static void USER_UnrecoveredErrHandler(void)
{
    printf(">> Unrecovered Error!\r\n");
}

/*!
 * @brief       USB delay
 *
 * @param       None
 *
 * @retval      None
 */
#if (DELAY_SOURCE != USE_DEFAULT)
static void USB_USER_Delay(uint32_t cnt)
{
    USB_usDelay(cnt);
}
#endif
