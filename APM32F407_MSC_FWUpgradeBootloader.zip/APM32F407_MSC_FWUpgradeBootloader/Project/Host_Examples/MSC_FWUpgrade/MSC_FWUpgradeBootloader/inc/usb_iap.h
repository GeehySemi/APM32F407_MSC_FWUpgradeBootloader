/*!
 * @file        usb_iap.h
 *
 * @brief       Header for usb_iap.c module
 *
 * @version     V1.0.0
 *
 * @date        2022-10-18
 *
 * @attention
 *
 *  Copyright (C) 2020-2022 Geehy Semiconductor
 *
 *  You may not use this file except in compliance with the
 *  GEEHY COPYRIGHT NOTICE (GEEHY SOFTWARE PACKAGE LICENSE).
 *
 *  The program is only for reference, which is distributed in the hope
 *  that it will be usefull and instructional for customers to develop
 *  their software. Unless required by applicable law or agreed to in
 *  writing, the program is distributed on an "AS IS" BASIS, WITHOUT
 *  ANY WARRANTY OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the GEEHY SOFTWARE PACKAGE LICENSE for the governing permissions
 *  and limitations under the License.
 */

/* Define to prevent recursive inclusion */
#ifndef __USB_IAP_H
#define __USB_IAP_H

/* Includes */
#include "apm32f4xx.h"
#include "bsp_flash.h"

#define IAP_UPLOAD_FILENAME         "0:image_upload.bin"
#define IAP_DOWNLOAD_FILENAME       "0:image.bin"
#define IAP_FILE_PATH               "0:/image.bin"
#define IAP_DISK_PATH               "0:"

/* In internal SRAM:
   This value can be equal to (512 * x) according to RAM size availability with x=[1, 128].
   In this project is fixed to 64 => 512 * 64 = 32768bytes = 32 Kbytes.
   You can use External SRAM to store more data for firmware upgrade. */
#define IAP_BUFFER_SIZE             ((uint16_t)512 * 64)

/*!
 * @brief    IAP operation type define
 */
typedef enum
{
    IAP_OP_OK,      /*!< IAP operation success */
    IAP_OP_ERROR    /*!< IAP operation error */
} IAP_OP_T;

/*!
 * @brief    Jump function pointer
 */
typedef void (*pFunction)(void);

void USB_IAP_Download(void);
void USB_IAP_Jump2App(void);
void USB_IAP_Upload(void);

#endif
